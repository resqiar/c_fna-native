package com.example.findnearbyapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Reference to Bottom Navigation View
        val bottomAppView = findViewById<BottomNavigationView>(R.id.bottom_app_view)

        // Disable the placeholder button from click event
        bottomAppView.menu.getItem(2).isEnabled = false
    }
}